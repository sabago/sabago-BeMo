<?php include __DIR__ . '/snippets/header.php' ?>

  <p class="notice">
    This page is currently offline due to an unexpected error. We are very sorry for the inconvenience and will fix it as soon as possible.
  </p>
  <p class="admin-advice">
    Advice for developers and administrators:<br>
    Enable <a href="https://getkirby.com/docs/reference/system/options/debug">debug mode</a> to get further information about the error.
  </p>

<?php include __DIR__ . '/snippets/footer.php' ?>
