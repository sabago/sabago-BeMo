<?php snippet('header') ?>

<main class="homepage">
    <?= $page->image() ?>

   
</main>

</body>
</html> 

