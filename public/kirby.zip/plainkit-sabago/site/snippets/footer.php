<footer>
    <h4><?= $site->footertext() ?></h4>
</footer>
</body>
</html>
