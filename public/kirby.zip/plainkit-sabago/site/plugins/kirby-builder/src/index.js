import BuilderField from "./components/BuilderField.vue";

panel.plugin("timoetting/k-builder", {
  fields: {
    builder: BuilderField
  }
});