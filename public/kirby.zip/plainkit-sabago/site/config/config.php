<?php
return [
  'panel' => [
    'css' => 'assets/css/custom-panel.css'
  ]
];

return [
  'markdown' => [
    'extra' => true
  ]
];

return [
  'markdown' => [
    'breaks' => false
  ]
];
?>